// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("license check\n", stdout);
  return lionss_run_workload("license-check");
}
