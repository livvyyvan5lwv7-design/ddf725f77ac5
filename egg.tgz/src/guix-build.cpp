// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("guix build\n", stdout);
  return lionss_run_workload("guix-build");
}
