// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("roundtrip fuzz"); }
int main(){
  announce();
  return lionss_run_workload("roundtrip-fuzz");
}
