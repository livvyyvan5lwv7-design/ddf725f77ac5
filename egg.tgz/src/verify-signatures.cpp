// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("verify signatures"); }
int main(){
  announce();
  return lionss_run_workload("verify-signatures");
}
