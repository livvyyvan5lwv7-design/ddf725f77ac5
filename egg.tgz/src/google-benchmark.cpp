// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("google benchmark"); }
int main(){
  announce();
  return lionss_run_workload("google-benchmark");
}
